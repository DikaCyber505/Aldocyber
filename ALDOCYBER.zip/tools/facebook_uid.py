uid = input("Masukkan UID Facebook: ")
print(f"Mencari info UID: {uid}...")
print("Fitur belum tersedia (mock info)")
